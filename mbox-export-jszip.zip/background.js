import { parse5322 } from "./modules/rfc5322/email-addresses.js";

// Generator function to loop more easily over message pages.
async function* listMessages(folder) {
  let page = await messenger.messages.list(folder);
  for (let message of page.messages) {
    yield message;
  }

  while (page.id) {
    page = await messenger.messages.continueList(page.id);
    for (let message of page.messages) {
      yield message;
    }
  }
}

async function exportFolder(exportItem, zip) {
  console.log("Exporting", exportItem);

  // If the item has an accountId, it is a folder, whose messages we can export.
  let mboxStrings = [];
  if (exportItem.accountId) {
    let messages = listMessages(exportItem);
    // listMessages() returns a generator, which makes the entire for loop async.
    for await (let message of messages) {
      let raw = await messenger.messages.getRaw(message.id);

      // From escaping according to mboxrd specifications.
      raw = raw.replace(/^(>*)(From\s)/m, "$1>$2");

      // Minimal compatibility.
      let parsed = parse5322.parseOneAddress(message.author);
      if (!parsed && message.author.indexOf("<") != -1) {
        let author = message.author.split("<");
        author[0] = `"${author[0]}"`;
        parsed = parse5322.parseOneAddress(author.join("<"));
      }
      let address = parsed ? parsed.address : message.author;
      raw = `From ${address} ${message.date.toUTCString()}\n` + raw;

      // Extra newline skipped for first message.
      // We cannot just create one large mbox string, as we could exceed the max
      // string limit and therefore cannot use join to sneak in the line break.
      if (mboxStrings.length > 0) {
        raw = "\n" + raw;
      }
      mboxStrings.push(raw);
    }
  }

  // Convert binary mbox strings to Uint8Array.
  let pos = 0;
  let mboxBytes = new Uint8Array(mboxStrings.reduce((total, item) => item.length + total, 0));
  for (let mboxString of mboxStrings) {
    for (let i = 0; i < mboxString.length; i++) {
      mboxBytes[pos++] = mboxString.charCodeAt(i) & 0xff;
    }
  }

  // If no zip object given, return just the buffer for mboxBytes.
  if (!zip) {
    return mboxBytes.buffer;
  }

  // Attach content of this folder as an mboxrd file.
  await zip.folder(exportItem.name).file(`${exportItem.name}.mboxrd`, mboxBytes);

  // Recursively attach subfolders.
  for (let subFolder of exportItem.subFolders || exportItem.folders) {
    await exportFolder(subFolder, zip.folder(exportItem.name));
  }
  return null;
}

function getReadableSize(bytes) {
  let units = ["KB", "MB", "TB"];
  let readableSize = units.reduce((rv, unit) => {
    if (rv.size / 1024 > 1) {
      return { size: rv.size / 1024, bytes, unit }
    } else {
      return rv
    }
  }, { size: bytes, bytes, unit: "B" });

  readableSize.roundedSize = Math.round(readableSize.size * 100) / 100;
  return readableSize;
}

// Menu click listener.
async function onExport(clickData, tab) {
  let exportItem = clickData.selectedFolder || clickData.selectedAccount;
  if (!exportItem || !tab.mailTab) {
    return;
  }

  let buffer;
  let type;
  let filename;
  if (exportItem.subFolders?.length || exportItem.folders?.length) {
    let zip = new JSZip();
    await exportFolder(exportItem, zip);
    console.log("START");
    buffer = await zip.generateAsync({ type: "arraybuffer" });
    console.log("STOP");
    type = "application/zip";
    filename = `${exportItem.name}.zip`;
  } else {
    buffer = await exportFolder(exportItem);
    type = "text/plain";
    filename = `${exportItem.name}.mbox`;
  }

  // The Blob constructor accepts a sequence and each element may not exceed 2GB,
  // split the data into smaller chunks.
  let pos = 0;
  let chunk = 1024 * 1024 * 1024;
  let sequence = [];
  while (pos + chunk <= buffer.byteLength) {
    sequence.push(new Uint8Array(buffer, pos, chunk));
    pos += chunk;
  }
  sequence.push(new Uint8Array(buffer, pos));

  let blob = new Blob(sequence, { type });
  let url = URL.createObjectURL(blob);
  let readableSize = getReadableSize(blob.size);
  console.log(`${readableSize.roundedSize} ${readableSize.unit} (${readableSize.bytes} bytes)`);

  // Initiate download.
  console.log("Downloading")
  let downloadId;
  try {
    downloadId = await browser.downloads.download({
      filename, 
      url, 
      saveAs: true
    });
  } catch (ex) {
    console.error(ex);
  }

  // Monitor download.
  if (downloadId) {
    // While the download is ongoing, we poll the download manager every second
    // to get an update. However, the "bytesReceived" are always the full size,
    // no incremental progress (probably because it is not a real download). :-(
    let pollId = window.setInterval(async () => {
      let [searching] = await browser.downloads.search({ id: downloadId });
      console.log(JSON.stringify(searching));
    }, 1000);

    await new Promise(resolve => {
      let listener = downloadDelta => {
        if (downloadDelta.id != downloadId) {
          return;
        }

        console.log(downloadDelta);
        if (downloadDelta.state && (
          downloadDelta.state.current == "complete" ||
          downloadDelta?.state.current == "interrupted"
        )) {
          browser.downloads.onChanged.removeListener(listener);
          resolve();
        }
      }
      browser.downloads.onChanged.addListener(listener);
    })

    window.clearInterval(pollId);
  }

  URL.revokeObjectURL(url);
  console.log("Done.");
}

async function onImport({ selectedFolder }, tab) {
  console.log(selectedFolder);
  let popupUrl = new URL(messenger.runtime.getURL("/popup/editemailsubjectPopup.html"));

  await messenger.windows.create({
    height: 170,
    width: 500,
    url: popupUrl.href,
    type: "popup"
  });
}

messenger.menus.create({
  contexts: ["folder_pane"],
  id: "mbox_export",
  title: "Export mboxrd files(s)",
  onclick: onExport
});

messenger.menus.create({
  contexts: ["folder_pane"],
  id: "mbox_import",
  title: "Import mboxrd file(s)",
  onclick: onImport
})
